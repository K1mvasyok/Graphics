#include <gl/gl.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <malloc.h>
#include "GameCamera.h"
using namespace std;

// ����� ��� �����
float vert[] = {1, 1, 2, 1, -1, 2, -1, -1, 2, -1, 1, 2, 0, 0, -1};
// ����� ��� ��������
float normal_vert[] = {1, 1, 2, 1, -1, 2, -1, -1, 2, -1, 1, 2, 0, 0, -1};
// ������ ����
int n = 20;

// ���������
void Init_Light() {

    glEnable(GL_LIGHTING);
    glEnable(GL_COLOR_MATERIAL);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_NORMALIZE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // �������� �����
    GLfloat light_position[] = { 0.0f, 0.0f, -2.0f, 1.0f };
    // ������� ����
    GLfloat light_spot_direction[] = {0.0, 0.0, -1.0, 1.0};
    GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
    GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat light_specular[] = { 0.0f, 0.0f, 0.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    // ����� ��� ������������� ���������
    glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 50);
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_spot_direction);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 10);

    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glEnable(GL_LIGHT0);
}
// ��������� ���������
void Init_Material() {
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glShadeModel(GL_SMOOTH);

    GLfloat material_specular[] = { 1.0f, 1.0f, 1.0f, 32.0f };
    GLfloat material_shininess[] = { 50.0f };

    glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);
}

void drawPrism(float radius1, float radius2, float height, float transparency, float x, float y, float z) {
    // ������������ ���� ����� ��������� �������
    float angle = (2.0f * 3.14159) / 5;

    // ������������ �������� ������
    float halfHeight = height / 2.0f;

    // ��������� ������� ������� �������������
    glPushMatrix();

    // ���������� ������ � ��������� ��������������
    glTranslatef(x, y, z);

    glBegin(GL_TRIANGLES);

    for (int i = 0; i < 6; i++) {
        // ��������� ���������� ������� ������� � ��������� �������
        float x1 = radius1 * cos(i * angle);
        float y1 = radius1 * sin(i * angle);
        float z1 = -halfHeight;

        float x2 = radius1 * cos((i + 1) * angle);
        float y2 = radius1 * sin((i + 1) * angle);
        float z2 = -halfHeight;

        float x3 = radius2 * cos(i * angle);
        float y3 = radius2 * sin(i * angle);
        float z3 = halfHeight;

        float x4 = radius2 * cos((i + 1) * angle);
        float y4 = radius2 * sin((i + 1) * angle);
        float z4 = halfHeight;

        // ������ �����
        glNormal3f(0.0f, 0.0f, -1.0f);
        glColor4f(0.0f, 1.0f, 0.0f, transparency);
        glVertex3f(x1, y1, z1);
        glVertex3f(x2, y2, z2);
        glVertex3f(0.0f, 0.0f, -halfHeight);

        // ������� �����
        glNormal3f(0.0f, 0.0f, 1.0f);
        glColor4f(0.0f, 1.0f, 0.0f, transparency);
        glVertex3f(x3, y3, z3);
        glVertex3f(x4, y4, z4);
        glVertex3f(0.0f, 0.0f, halfHeight);

        // ������� �����
        glVertex3f(x1, y1, z1);
        glVertex3f(x3, y3, z3);
        glVertex3f(x2, y2, z2);

        glVertex3f(x2, y2, z2);
        glVertex3f(x3, y3, z3);
        glVertex3f(x4, y4, z4);

        glVertex3f(x3, y3, z3);
        glVertex3f(x4, y4, z4);
        glVertex3f(0.0f, 0.0f, halfHeight);

        glVertex3f(x4, y4, z4);
        glVertex3f(0.0f, 0.0f, halfHeight);
        glVertex3f(x3, y3, z3);
    }

    glEnd();
    glPopMatrix();
}
// ���������� � �����
void MovePlayer() {
    CameraDirectional(GetKeyState('W')<0 ? 1 : (GetKeyState('S')< 0 ? -1 : 0),
                           GetKeyState('D')<0 ? 1 : (GetKeyState('A')< 0 ? -1 : 0),
                           0.1);
    CamerAutoMouse(400,400,0.5);
}
// ��������� �����
void ShowChessBoard() {
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT,0,&normal_vert);
    glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, &vert);
        for (int i = -n/2; i < n/2; i++)
            for (int j = -n/2; j < n/2; j++) {
                glPushMatrix();
                    if ((i + j) % 2 == 0)
                        //����� ������� �������
                        glColor3f(1.0f, 1.0f, 1.0f);
                    else
                    // ������ �������
                        glColor3f(0, 0, 0);

                    glTranslatef(i * 2, j * 2, 0);
                    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
                glPopMatrix();
            }
            // ������ �����
                glLineWidth(1);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisable(GL_NORMAL_ARRAY);
    glBegin(GL_LINES);
        glColor3d(1,0,0);
        glVertex3f(-900,0,0);
        glVertex3f(900,0,0);
        glColor3d(0,1,0);
        glVertex3f(0,-900,0);
        glVertex3f(0,900,0);
        glColor3d(0,0,1);
        glVertex3f(0,0,-900);
        glVertex3f(0,0,900);
    glEnd( );
}
void windowResize(HWND hwnd) {
    RECT rct;
    GetClientRect(hwnd, &rct);
    int width = rct.right - rct.left;
    int height =rct.bottom - rct.top;
    glViewport(0, 0,width , height);
}
LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;
    float theta = 0.0f;

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;


    if (!RegisterClassEx(&wcex))
        return 0;

    hwnd = CreateWindowEx(0,
                          "GLSample",
                          "lab 7",
                          WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          900,
                          900,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ShowWindow(hwnd, nCmdShow);

    EnableOpenGL(hwnd, &hDC, &hRC);
    // ������������ ������
    glFrustum(-1,1, -1,1, 2,900);
    //����� �������
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_NORMALIZE);
    Init_Light();
    Init_Material();
    ShowCursor(false);


    while (!bQuit) {

        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {

            if (msg.message == WM_QUIT) {
                bQuit = TRUE;
            }
            else {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else {

            glClearColor(0.2f, 0.2f, 0.2f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glPushMatrix();
                CameraApply();
                MovePlayer();
                windowResize(hwnd);
                ShowChessBoard();

                // ��������� ������(radius1, radius2, height, transparency, x, y, z)
                 drawPrism(1.0f, 2.0f, 3.0f, 0.20f, 14.0f, 2.0f, 0.0f);
                 drawPrism(1.0f, 2.0f, 3.0f, 0.40f, 9.0f, 2.0f, 0.0f);
                 drawPrism(1.0f, 2.0f, 3.0f, 0.60f, 4.0f, 2.0f, 0.0f);
                 drawPrism(1.0f, 2.0f, 3.0f, 0.80f, -1.0f, 2.0f, 0.0f);
                 drawPrism(1.0f, 2.0f, 3.0f, 1.0f, -6.0f, 2.0f, 0.0f);

            glPopMatrix();
            SwapBuffers(hDC);
            Sleep (1);
        }
        if(GetKeyState(VK_ESCAPE)<0) {
            bQuit = TRUE;
        }
    }

    DisableOpenGL(hwnd, hDC, hRC);
    DestroyWindow(hwnd);

    return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;
        case WM_DESTROY:
            return 0;
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC) {
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;


    *hDC = GetDC(hwnd);


    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);


    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC) {
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}


